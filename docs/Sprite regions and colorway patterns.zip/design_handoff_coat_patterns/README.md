# Handoff: tokitty coat regions & colorway/pattern look-space (sprites.py Tasks 8–9)

## Overview
Splits tokitty's single fixed "coat" into two orthogonal axes — **colorway** (a 5-slot tone palette) × **pattern** (a per-region tone map) — and carves **4 new recolorable regions** (paws, points, tail, belly) into the three base sprite templates so patterns have real surface area to work on. This is the art/data half of Tasks 8–9; the resolver/engine (Tasks 1–7) already exists.

## About the design files
The single file in this bundle, `Tokitty Coat Patterns.dc.html`, is a **design reference / interactive proof**, not production code. It reimplements the tokitty renderer in JS+canvas purely to *visualize* the grid edits and data at the real 28×26 / 4× pixel scale (region-debug view, ringed-tail spike, full colorway×pattern contact sheet). **Do not ship the HTML.** The actual deliverable is the character-grid + hex data below, which drops into `tokitty/sprites.py`. "Recreate in the target codebase" here means: apply these exact grid strings and dicts to `sprites.py` and run the project's existing verification gates.

## Fidelity
**Hi-fi.** Every cell coordinate and every hex is final and exact. Grid edits are authoritative to the pixel.

## The model (recap)
- Art is pixel-art on a fixed **28 wide × 26 tall** character grid stored as Python string lists; each char → one color via a palette dict; renderer scales 4× (each cell → 4×4 device px). `.` = transparent.
- A **region** is the set of cells sharing a palette char. `REGION_CHARS` is a **closed set of 8** (a test enforces exactly these keys per pattern).
- Only **3 base templates** are edited (`SITTING`, `ALERT`, `FLOPPED`); the 4 prop poses (working/thinking/permission/done-hop) stamp props on top and inherit the edits for free.

## REGION_CHARS
```python
REGION_CHARS = ("o", "O", "s", "c", "m", "x", "y", "u")
```
New in Tasks 8–9: **m = paws** (was `w`), **x = points** = outer ears + face mask (was `o`), **y = tail** (was `O`), **u = belly** (was `w`). Identity-preserving defaults: m/u→white, x→coat, y→shade.

## PATTERNS (full, all 8 keys each)
```python
PATTERNS = {
    "solid":      {"o":"coat", "O":"shade", "s":"coat", "c":"coat", "m":"coat", "x":"coat", "y":"shade", "u":"coat"},
    "tabby":      {"o":"coat", "O":"shade", "s":"mark", "c":"coat", "m":"white", "x":"coat", "y":"shade", "u":"white"},
    "bicolor":    {"o":"coat", "O":"shade", "s":"coat", "c":"white", "m":"white", "x":"coat", "y":"shade", "u":"white"},
    "tabby_white":{"o":"coat", "O":"shade", "s":"mark", "c":"white", "m":"white", "x":"coat", "y":"shade", "u":"white"},
    "calico":     {"o":"coat", "O":"shade", "s":"#453a33", "c":"#e8823c", "m":"white", "x":"coat", "y":"shade", "u":"white"},
    "tuxedo":     {"o":"coat", "O":"shade", "s":"coat", "c":"white", "m":"white", "x":"coat", "y":"shade", "u":"white"},
    "socks":      {"o":"coat", "O":"shade", "s":"coat", "c":"coat", "m":"white", "x":"coat", "y":"shade", "u":"coat"},
    "colorpoint": {"o":"light", "O":"light", "s":"light", "c":"light", "m":"mark", "x":"mark", "y":"mark", "u":"light"},
    "van":        {"o":"white", "O":"shade", "s":"white", "c":"white", "m":"white", "x":"coat", "y":"coat", "u":"white"},
    "ringed":     {"o":"coat", "O":"shade", "s":"mark", "c":"coat", "m":"coat", "x":"coat", "y":"shade", "u":"white"},
}
```
- `solid tabby bicolor tabby_white tuxedo socks` are **colorway-friendly** (reference tone tokens → every colorway × these is a clean, intentional look).
- `calico colorpoint van` express a **base↔accent** relationship, not one base color. `colorpoint`/`van` remap the body toward `light`, so **dark colorways × these look muddy** — expected and acceptable, not a bug.
- **Ringed-tail verdict: GO.** At 4× the curl is ~2 cells wide, so alternating bands read as rings, not mud (validated in the spike). `van` + `ringed` ship. **Real `ringed` still needs the tail split into two alternating chars (e.g. `y` / `Y`)** — the HTML fakes it by banding the `y` cells; if you don't add a second char, `ringed` renders a flat shade tail.

## COLORWAYS
Legacy 4 kept byte-identical for coat/shade/mark/ear; **`light` is new** (only `colorpoint`/`van` use it) and tuned as a believable pale coat for all 6. Two new colorways added.
```python
COLORWAYS = {
    "orange":{"coat":"#e8823c", "shade":"#c26a2c", "mark":"#a8541f", "light":"#f7e0c0", "ear":"#f6b8c8"},
    "gray": {"coat":"#a4aec2", "shade":"#818ba0", "mark":"#5f6879", "light":"#e2e7f0", "ear":"#e3a9ba"},
    "black":{"coat":"#4a4653", "shade":"#38343f", "mark":"#575263", "light":"#cfccd9", "ear":"#a8798c"},
    "white":{"coat":"#f1ebdf", "shade":"#c4bcae", "mark":"#ded6c6", "light":"#f8f4ec", "ear":"#f6b8c8"},
    "cream":{"coat":"#e9d9bd", "shade":"#cdb894", "mark":"#a98d63", "light":"#f7efdd", "ear":"#f0c4cf"},
    "brown":{"coat":"#8a5a3c", "shade":"#6d452d", "mark":"#4f3020", "light":"#d9c4ab", "ear":"#d69aa6"},
}
```

## Region carving — authoritative per-cell edits
Apply against the **verbatim original** templates. Each listed cell's char is replaced by the region char; every replaced cell currently holds the identity-preserving source char (paws/belly←`w`, points←`o`, tail←`O`), so under legacy patterns the render is unchanged (see byte-identity flags). Coordinates are **(row, col)**, 0-indexed, row 0 = top.

### SITTING
- `x` (points): (1,8) (1,18) (2,7) (2,8) (2,9) (2,17) (2,18) (2,19) (3,6) (3,7) (3,8) (3,9) (3,17) (3,18) (3,19) (3,20) (4,6) (4,7) (4,9) (4,10) (4,16) (4,17) (4,19) (4,20) (8,11) (8,12) (8,13) (8,14) (8,15) (9,11) (9,12) (9,14) (9,15) (10,9) (10,10) (10,16) (10,17) (11,8) (11,9) (11,17) (12,9) (12,10) (12,16) (13,11) (13,12) (13,14) (13,15)
- `y` (tail): (14,21) (14,22) (15,22) (15,23) (16,23) (16,24) (17,23) (17,24) (18,24) (18,25) (19,24) (19,25) (20,24) (20,25) (21,23) (21,24) (22,22) (22,23) (23,21) (23,22)
- `u` (belly): (18,11) (18,12) (18,13) (18,14) (18,15) (19,10) (19,11) (19,12) (19,13) (19,14) (19,15) (19,16) (20,10) (20,11) (20,12) (20,13) (20,14) (20,15) (20,16) (21,9) (21,10) (21,11) (21,12) (21,13) (21,14) (21,15) (21,16) (21,17) (22,10) (22,11) (22,12) (22,13) (22,14) (22,15) (22,16) (23,10) (23,11) (23,12) (23,13) (23,14) (23,15) (23,16)
- `m` (paws): (24,10) (24,11) (24,12) (24,13) (24,14) (24,15) (24,16)
Notes: tail `y` = the descending curl only; the `O` running up the side of the face **stays `O`** (shade). Muzzle `w` cells stay `w`.

### ALERT
- `x` (points): (0,8) (0,18) (1,8) (1,18) (2,7) (2,18) (3,6) (3,7) (3,9) (3,10) (3,16) (3,17) (3,19) (3,20) (4,6) (4,7) (4,18) (4,19) (7,11) (7,12) (7,13) (7,14) (7,15) (8,11) (8,12) (8,14) (8,15) (9,9) (9,10) (9,16) (9,17) (10,8) (10,9) (10,17) (11,9) (11,10) (11,16)
- `y` (tail): (14,21) (14,22) (15,22) (15,23) (16,23) (16,24) (17,23) (17,24) (18,24) (18,25) (19,24) (19,25) (20,24) (20,25) (21,23) (21,24) (22,22) (22,23) (23,21) (23,22)
- `u` (belly): (18,11) (18,12) (18,13) (18,14) (18,15) (19,10) (19,11) (19,12) (19,13) (19,14) (19,15) (19,16) (20,10) (20,11) (20,12) (20,13) (20,14) (20,15) (20,16) (21,9) (21,10) (21,11) (21,12) (21,13) (21,14) (21,15) (21,16) (21,17) (22,10) (22,11) (22,12) (22,13) (22,14) (22,15) (22,16) (23,10) (23,11) (23,12) (23,13) (23,14) (23,15) (23,16)
- `m` (paws): (24,10) (24,11) (24,12) (24,13) (24,14) (24,15) (24,16)
Notes: only the far-right descending `O` is tail; shoulder-shade `O` (rows 5–11) and row-24 haunch `O` (cols 9,17) **stay `O`**.

### FLOPPED
- `x` (points): (3,4) (3,5) (4,3) (4,4) (4,6) (5,3) (5,4) (3,12) (3,13) (4,10) (4,12) (4,13) (5,12) (5,13) (12,5) (12,6) (12,7) (12,9) (12,10) (12,11) (13,4) (13,5) (13,11) (13,12) (14,4) (14,5) (14,11) (14,12) (15,5) (15,6) (15,10) (15,11)
- `y` (tail): (16,26) (16,27) (17,26) (17,27) (18,25) (18,26) (18,27) (19,25) (19,26) (20,25)
- `u` (belly): (19,13) (19,14) (19,15) (19,16) (19,17) (20,12) (20,13) (20,14) (20,15) (20,16) (20,17) (21,12) (21,13) (21,14) (21,15) (21,16) (21,17) (21,18) (22,12) (22,13) (22,14) (22,15) (22,16) (22,17) (22,18)
- `m` (paws): (18,3) (18,4) (19,2) (19,3) (21,2) (21,3) (22,2) (22,3) (22,26) (22,27) (23,26) (23,27)
Notes: no `O`→`y` carve here. The tail = the resting curl `y` cells (rows 16–20, far right) **plus** the animated sweep cells `1–5` (see resolver). The far-right hind paw (`m`) stays separate from the tail — rows 20–21 col 26/27 are empty, keeping them apart.

## Resolver behavior (unchanged shape + one addition)
```python
def resolve_palette(colorway, pattern):
    cw = COLORWAYS[colorway]
    tones = {"coat":cw["coat"], "shade":cw["shade"], "mark":cw["mark"],
             "light":cw["light"], "white":BASE_PALETTE["w"]}
    merged = dict(BASE_PALETTE)
    merged["p"] = cw["ear"]                 # inner-ear pink = colorway.ear (NOT pattern-driven)
    for char, src in PATTERNS[pattern].items():
        merged[char] = tones.get(src, src)  # tone token -> tone, else literal hex
    # NEW: FLOPPED animated tail sweep chars follow the tail tone
    tail = merged.get("y", cw["coat"])
    for d in "12345":
        merged[d] = tail
    return merged
```
The `1–5` binding is what makes the flopped tail recolor under van/colorpoint/ringed. `p` (inner-ear pink) is colorway-driven — **leave it out of patterns**.

## Byte-identity flags (deliberate, non-negotiable to review)
1. **`solid`**: the map sets `m/u = coat`, so `solid` now has a coat-colored belly/paws (a true solid) instead of today's white-bellied "solid". That one legacy look is **not** byte-identical — intentional.
2. **FLOPPED tail**: binding the sweep to `y` shifts the flopped legacy tail coat→shade (tail no longer has its own char; it inherits the shared `y` default). Deliberate, to make the flopped tail recolorable.
Every other legacy look/region re-renders pixel-identical.

## Pruning
None. No whole pattern is muddy in *every* colorway. Weakest corners (accepted): `colorpoint`×`white` and `van`×`white` (near-zero pigment contrast), `colorpoint`/`van` on `black`/`brown` (dark, muted).

## Full edited templates (drop-in)
```python
SITTING_TEMPLATE = [
    "............................",
    "........x.........x.........",
    ".......xxx...o...xxx........",
    "......xxxxoooooooxxxx.......",
    "......xxpxxsssssxxpxx.......",
    ".....ooocccoooooooooOO......",
    ".......occsssosssoOO........",
    ".......oooooooooooOO........",
    "......ooooLxxxxxRooOO.......",
    ".......ooooxxwxxooOO........",
    ".......ooxxwwAwwxxOO........",
    ".......oxxwwwwwwwxOO........",
    "........oxxwwwwwxOO.........",
    ".........ooxxwxxOO..........",
    "........ooooooooooo..yy.....",
    ".......ooooooooooooo..yy....",
    "......ooooooooooooooo..yy...",
    "......osssooowooooooo..yy...",
    "......ooooouuuuuooooo...yy..",
    ".....osssouuuuuuucccoo..yy..",
    "......oooouuuuuuuccco...yy..",
    "......ooouuuuuuuuucco..yy...",
    "......oooouuuuuuuoooo.yy....",
    ".......ooouuuuuuuooo.yy.....",
    "........oommmmmmmOO.........",
    ".........oooooooOO..........",
]

ALERT_TEMPLATE = [
    "........x.........x.........",
    "........x....o....x.........",
    ".......xpoooooooooxo........",
    "......xxpxxsssssxxpxx.......",
    "......xxcccoooooooxxo.......",
    ".......occsssosssoOO........",
    ".......oooooooooooOO........",
    "......ooooLxxxxxRooOO.......",
    ".......ooooxxwxxooOO........",
    ".......ooxxwwAwwxxOO........",
    ".......oxxwwwwwwwxOO........",
    "........oxxwwwwwxOO.........",
    "..........ooowoOO...........",
    "..........oooooOO...........",
    ".........ooooooooo...yy.....",
    "........ooooooooooo...yy....",
    ".......ooooooooooooo...yy...",
    ".......sssooowoooooo...yy...",
    ".......oooouuuuuoooo....yy..",
    "......sssouuuuuuuccco...yy..",
    ".......ooouuuuuuuccc....yy..",
    ".......oouuuuuuuuucc...yy...",
    ".......ooouuuuuuuooo..yy....",
    "........oouuuuuuuoo..yy.....",
    ".........OmmmmmmmO..........",
    "..........oooooOO...........",
]

FLOPPED_TEMPLATE = [
    "............................",
    "............................",
    "............................",
    "....xx......xx..............",
    "...xxpx...xpxx..............",
    "...xxpooooopxx..............",
    "...ooooooooooo..............",
    "...oooosssoooo..............",
    "..ooooooooooooo.............",
    "..oossooooossoo.............",
    "..ooooooooooooo.............",
    "..oooLooookkooo.............",
    "..oooxxxnxxxooo........1..23",
    "..ooxxwwwwwxxoo........11223",
    "...oxxwwwwwxxooossoooo..1453",
    "....oxxwwwxxooooooossoo.1453",
    ".....oOOOOOoooooooooooss.4yy",
    "......OOOOOooooooooOoooo..yy",
    "...mmoooooooooooooOooooo.yyy",
    "..mmooooooooouuuuuOoccoooyy.",
    "...........ouuuuuuOccccooy..",
    "..mmoooooooouuuuuuuOoccoo...",
    "..mmoooooooouuuuuuuooooooomm",
    "........................oomm",
    "............................",
    "............................",
]
```

## Verification gates (the bar)
1. **Byte-identity** re-render of the 5 legacy looks (except the two flags above).
2. **Per-region debug render** (paint m/x/y/u loud) + a differentiating pattern (socks/colorpoint) — the real placement check.
3. **Contact sheet** of the full colorway×pattern space for the muddy-combo prune.

## Files
- `Tokitty Coat Patterns.dc.html` — interactive design reference (renderer, region-debug, ringed spike, contact sheet, and this same data generated live in its "Deliverable" panel).
